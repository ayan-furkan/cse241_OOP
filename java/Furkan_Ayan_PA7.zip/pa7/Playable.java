package pa7;

public interface Playable  {
    public void info();
}

