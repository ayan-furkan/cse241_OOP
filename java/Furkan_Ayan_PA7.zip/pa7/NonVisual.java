package pa7;

public interface NonVisual  {
    public void info();
}
    

