package pa7;

public interface NonPlayable  {
    public void info();
}
