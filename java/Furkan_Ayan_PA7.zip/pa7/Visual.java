package pa7;

public interface Visual  {
    public void info();
}
