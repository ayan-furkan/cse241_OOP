#ifndef USER_H
#define USER_H

#include <iostream>

namespace Authenticate{
    void inputUserName();
    std::string getUserName();
}

#endif