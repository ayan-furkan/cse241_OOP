#ifndef PASSWORD_H
#define PASSWORD_H

#include <iostream>

namespace Authenticate{
    void inputPassword();
    std::string getPassword();
}

#endif