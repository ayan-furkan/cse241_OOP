#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main(){
    
    char array1[20];
    char array2[20];
    int array1Size = 0;
    int array2Size = 0;


    cout << "1: ";
    cin >> array1;
    

    cout << "2: ";
    cin >> array2;

}